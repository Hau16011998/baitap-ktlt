n= int(input("enter A number--->"));
while n >=0:
        print (n);
        n = n-1;
             
