a="hi i am pyton programmer"
b=a.split()
print (b)
c=" ".join(b)
print (c)
