a=int (input("enter a value:"))
b=int (input("enter b value:"))
if  a>b :
    print("a is big")
else:
    print("b is big")
