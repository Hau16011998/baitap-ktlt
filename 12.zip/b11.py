l=[1,'python',4,7]
k=['cse',2,'gntur',8]
m=[]
m.append(1);
m.append(k);
print(m)
d={1:1,2:k,'combine_list':m}
print(d)
