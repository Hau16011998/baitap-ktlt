n=int (input("enter a number---->"))
if n % 2 == 0:
    print ("EVEN Number");
else :
    print ("ODD number");
